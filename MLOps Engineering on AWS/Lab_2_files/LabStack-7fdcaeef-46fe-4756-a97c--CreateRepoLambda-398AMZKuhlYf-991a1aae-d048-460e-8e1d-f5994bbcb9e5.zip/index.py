import boto3, sys, os, json
import random, string, re
import botocore
import uuid, shutil
import urllib.request
import logging
import urllib3
http = urllib3.PoolManager()


codeCommit = boto3.client('codecommit')
s3 = boto3.resource('s3')
lambdaClient = boto3.client('lambda')
ecr = boto3.client('ecr')

def lambda_handler(event, context):
  print(event)
  responseData = {'status': 'NONE', 'repoName': 'NONE'}
  if event['RequestType'] == 'Create':
    
    bucketName = event['ResourceProperties'].get('BucketName')
    keyPrefix = event['ResourceProperties'].get('KeyPrefix')
    Region = event['ResourceProperties'].get('Region')

    randStr = uuid.uuid4().hex

    if (keyPrefix == 'demo'):
      try:
        # Copy the files from the Amazon S3 bucket
        s3.meta.client.download_file(bucketName, 'repoCode.zip', '/tmp/repoCode.zip' )
      except Exception as e:
        print(e)
    else:
      source_url = 'https://'+bucketName+'.s3-'+Region+'.amazonaws.com/'+keyPrefix+'/scripts/repoCode.zip'
      print(source_url)
      try:
        urllib.request.urlretrieve(source_url, '/tmp/repoCode.zip')
      except:
        raise
    localDirectory = '/tmp/unzip/'
    try:
      shutil.unpack_archive('/tmp/repoCode.zip', localDirectory , 'zip')
    except:
      e = sys.exc_info()[0]
      f = sys.exc_info()[1]
      g = sys.exc_info()[2]
      print("error (main error): "+str(e) + str(f) + str(g))

    fileDirectory = localDirectory + 'ModelCode'
    repoType = 'ModelCode'
    repoName = repoType+'-'+randStr
    repoDescription = 'This repository contains all the model code.'
    createRepo(event, context, repoName, repoDescription, repoType, responseData, bucketName, keyPrefix, fileDirectory)

    fileDirectory = localDirectory + 'StateMachineCode'
    repoType = 'StateMachineCode'
    repoName = repoType+'-'+randStr
    repoDescription = 'This repository contains the code to create the AWS Step-Functions.'
    createRepo(event, context, repoName, repoDescription, repoType, responseData, bucketName, keyPrefix, fileDirectory)

    responseData['status'] = 'CREATED'
    responseData['repoId'] = randStr
    sendResponse(event, context, "SUCCESS", responseData, event["LogicalResourceId"])
  elif event['RequestType'] == 'Delete':

    # Get a list of all images in the ECR repo
    try:
      response = ecr.list_images(
          repositoryName=event['ResourceProperties'].get('ECRModelRepo')
      )
    except:
      e = sys.exc_info()[0]
      f = sys.exc_info()[1]
      g = sys.exc_info()[2]
      print("error (list_images error): "+str(e) + str(f) + str(g))
    # Create an array of images to delete
    imageIds = []
    for image in response['imageIds']:
        print(image['imageDigest'])
        thisImage = { 'imageDigest': image['imageDigest'] }
        imageIds.append(thisImage)
    # Delete the images from the repo
    try:
      ecr.batch_delete_image(
          repositoryName=event['ResourceProperties'].get('ECRModelRepo'),
          imageIds=imageIds
      )
    except:
      e = sys.exc_info()[0]
      f = sys.exc_info()[1]
      g = sys.exc_info()[2]
      print("error (batch_delete_images error): "+str(e) + str(f) + str(g))

    try:
      # Delete the files in the data bucket and the ecr bucket
      s3.Bucket( event['ResourceProperties'].get('ModelDataBucket') ).object_versions.all().delete()
      s3.Bucket( event['ResourceProperties'].get('ModelArtifactBucket') ).object_versions.all().delete()
    except:
      sendResponse(event, context, "FAILED", responseData, event["LogicalResourceId"])
    try:
      s3.Bucket( event['ResourceProperties'].get('ECRBucket') ).object_versions.all().delete()
    except:
      sendResponse(event, context, "FAILED", responseData, event["LogicalResourceId"])

    repoName=os.environ['ModelCode']
    try:
      response = codeCommit.delete_repository(repositoryName=repoName)
    except:
      sendResponse(event, context, "FAILED", responseData, event["LogicalResourceId"])
    repoName=os.environ['StateMachineCode']
    try:
      response = codeCommit.delete_repository(repositoryName=repoName)
    except:
      sendResponse(event, context, "FAILED", responseData, event["LogicalResourceId"])

    responseData['status'] = 'DELETED'
    sendResponse(event, context, "SUCCESS", responseData, event["LogicalResourceId"])

# This sends the data to CFN to signal success or fail. I am using this code instead of using cfn_response because
# Lambda is deprecating support for the requests module. This uses Curl instead.
def sendResponse(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
  # Setup Arrays to pass data to CloudFormation so it gets a success signal
  responseBody = {}
  responseBody['Status'] = responseStatus
  responseBody['Reason'] = 'Configuration Complete. See the details in CloudWatch Log Stream: ' + context.log_stream_name
  responseBody['PhysicalResourceId'] = physicalResourceId or context.log_stream_name
  responseBody['StackId'] = event['StackId']
  responseBody['RequestId'] = event['RequestId']
  responseBody['LogicalResourceId'] = event['LogicalResourceId']
  responseBody['UniqueId'] = 'RequestPassed1'
  responseBody['Data'] = responseData
  json_responseBody = json.dumps(responseBody)
  # # print("Response body:\n" + json_responseBody)
  # curlCMD = "curl -X PUT -H 'Content-Type:' --data-binary '" + json_responseBody + "' \"" + event["ResponseURL"] + "\""
  # # print(curlCMD)
  # try:
  #   os.system(curlCMD)
  # except Exception as e:
  #   print('Error: ' + str(e))

  responseUrl = event['ResponseURL']

  print("Response body:\n" + json_responseBody)

  headers = {
      'content-type' : '',
      'content-length' : str(len(json_responseBody))
  }
  try:
      response = http.request('PUT',responseUrl,body=json_responseBody.encode('utf-8'),headers=headers)
      print("Status code: " + response.reason)
  except Exception as e:
      print("send(..) failed executing requests.put(..): " + str(e))


def createRepo(event, context, repoName, repoDescription, repoType, responseData, bucketName, keyPrefix, fileDirectory):
  try:
    response = codeCommit.create_repository(
      repositoryName=repoName,
      repositoryDescription=repoDescription)
  except:
    e = sys.exc_info()[0]
    f = sys.exc_info()[1]
    g = sys.exc_info()[2]
    print("error (main error): "+str(e) + str(f) + str(g))
    responseData['Data'] = f"Exception raised for function: \nException details: \n{e}"
    sendResponse(event, context, "FAILED", responseData, event["LogicalResourceId"])
  try:
    envVars = {}
    # Get the current environmental variables so you don't overwrite any
    print(os.environ['AWS_LAMBDA_FUNCTION_NAME'])
    lambdaEnvVars = lambdaClient.get_function_configuration(FunctionName=os.environ['AWS_LAMBDA_FUNCTION_NAME'])
    try:
      lambdaEnvVars['Environment']['Variables']
    except:
      print("Variable not defined.")
    else:
      envVars = lambdaEnvVars['Environment']['Variables']
    envVars[repoType] = repoName
    # Update the environmental variables to use for deleting the repos
    lambdaResponse = lambdaClient.update_function_configuration(
      FunctionName=os.environ['AWS_LAMBDA_FUNCTION_NAME'],
      Environment={
        'Variables': envVars
      },
    )
  except:
    e = sys.exc_info()[0]
    print("error (update lambda function): "+str(e))
    responseData['Data'] = f"Exception raised for function: \nException details: \n{e}"
    sendResponse(event, context, "FAILED", responseData, event["LogicalResourceId"])

  # putFiles = createFileVariable(event, context, keyPrefix, fileDirectory, bucketName)
  putFiles = createFile(event, context, keyPrefix, fileDirectory)
  # Create an initial commit with files from above
  try:
    response = codeCommit.create_commit(repositoryName=repoName, branchName='main', commitMessage='Initial commit with sample files', putFiles=putFiles)
  except:
    print('adding commit failed')
    e = sys.exc_info()[0]
    f = sys.exc_info()[1]
    g = sys.exc_info()[2]
    print("error (main error): "+str(e) + str(f) + str(g))
    print('------')
    sendResponse(event, context, "FAILED", responseData, event["LogicalResourceId"])
  try:
    codeCommit.create_branch(repositoryName=repoName, branchName='main',  commitId=response['commitId'])
  except:
    print('Creating branch failed')
    sendResponse(event, context, "FAILED", responseData, event["LogicalResourceId"])

def createFile(event, context, keyPrefix, fileDirectory):
  print("::createFile::")
  print(fileDirectory)
  putFiles = []
  binFile = False
  print('All the files::::')
  for root, dirs, files in os.walk(fileDirectory):
    for filename in files:
      fullFileName = root+'/'+filename
      print(fullFileName)
      try:
        openFile = open(fullFileName, 'r')
      except:
        e = sys.exc_info()[0]
        f = sys.exc_info()[1]
        g = sys.exc_info()[2]
        print("error (open error): "+str(e) + str(f) + str(g))
      # Try to read the file contents
      try:
        fileContent = openFile.read()
      except: # If you get an error, its probably a binary file, so try that.
        openFile = open(fullFileName, 'rb')
        fileContent = openFile.read()
        binFile = True
        e = sys.exc_info()[0]
        f = sys.exc_info()[1]
        g = sys.exc_info()[2]
        print("error (read error): "+str(e) + str(f) + str(g))
      if binFile:
        sendContent = fileContent
        binFile = False
      else:
        if filename == 'state_machine_manager.py':
          fileContent = fileContent.replace('[SageMakerRole]', event['ResourceProperties'].get('SageMakerRole'))
          fileContent = fileContent.replace('[StepFunctionsRole]', event['ResourceProperties'].get('StepFunctionsRole'))
          fileContent = fileContent.replace('[AccountId]', context.invoked_function_arn.split(":")[4])
          fileContent = fileContent.replace('[Region]', os.environ['AWS_REGION'])
          fileContent = fileContent.replace('[ECRModelRepo]', event['ResourceProperties'].get('ECRModelRepo'))
          fileContent = fileContent.replace('[TrainingStateMachine]', event['ResourceProperties'].get('TrainingStateMachine'))
          fileContent = fileContent.replace('[TrainingStateMachineName]', event['ResourceProperties'].get('TrainingStateMachineName'))
          fileContent = fileContent.replace('[EndpointWaitLambda]', event['ResourceProperties'].get('EndpointWaitLambda'))
          fileContent = fileContent.replace('[ModelTestLambda]', event['ResourceProperties'].get('ModelTestLambda'))
          fileContent = fileContent.replace('[ModelArtifactBucket]', event['ResourceProperties'].get('ModelArtifactBucket'))
          fileContent = fileContent.replace('[KMSKey]', event['ResourceProperties'].get('KMSKey'))
        if filename == 'buildspec.yml':
          fileContent = fileContent.replace('[AccountId]', context.invoked_function_arn.split(":")[4])
          fileContent = fileContent.replace('[Region]', os.environ['AWS_REGION'])
          fileContent = fileContent.replace('[TrainingStateMachine]', event['ResourceProperties'].get('TrainingStateMachine'))
        sendContent = fileContent.encode()

      newFile = {
        'filePath': fullFileName.replace(fileDirectory, ''),
        'fileMode': 'NORMAL',
        'fileContent': sendContent
        }
      putFiles.append(newFile)
  print('All the files::::')

  return(putFiles)
