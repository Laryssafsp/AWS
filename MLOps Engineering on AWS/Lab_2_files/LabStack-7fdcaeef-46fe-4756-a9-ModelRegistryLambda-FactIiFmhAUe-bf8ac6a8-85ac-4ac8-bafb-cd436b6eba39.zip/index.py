import json, boto3, os, datetime, logging, sys, re, time, random, decimal

sagemaker = boto3.client('sagemaker')
s3 = boto3.resource('s3')

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(json.dumps(event))

    # Set the variables
    try:
        # Run from CodePipeline
        ecr_arn = event['Input']['ECRArn']
        artifact_bucket = event['Input']['ModelArtifactBucket']
        region = event['Input']['Region']
        job_name = event['Input']['Job']
        version = event['Input']['DataBucketPath'].split('/')[3]
        data_bucket = event['Input']['DataBucketPath'].split('/')[2]
    except KeyError as e:
        # Run manually
        ecr_arn = event['ECRArn']
        artifact_bucket = event['ModelArtifactBucket']
        region = event['Region']
        job_name = event['Job']
        version = event['DataBucketPath'].split('/')[3]
        data_bucket = event['DataBucketPath'].split('/')[2]
    
    model_url = f"https://{artifact_bucket}.s3.{region}.amazonaws.com/{job_name}/output/model.tar.gz"

    # Find if there is a model package group
    try:
        model_package_group_name = sagemaker.list_model_package_groups()['ModelPackageGroupSummaryList'][0]['ModelPackageGroupName']
        print(f'The model package is: {model_package_group_name}')
    except IndexError as e:
        # There is no model package group yet. Create one.
        print('Creating a model package group...')
        model_package_group_name = "abalone-model-group-" + str(round(time.time()))
        model_package_group_input_dict = {
            "ModelPackageGroupName" : model_package_group_name,
            "ModelPackageGroupDescription" : "Sample model package group"
        }
            
        create_model_package_group_response = sagemaker.create_model_package_group(**model_package_group_input_dict)
            
        model_package_group_name = sagemaker.list_model_package_groups()['ModelPackageGroupSummaryList'][0]['ModelPackageGroupName']
        print(f'The model package is: {model_package_group_name}')

    # AUC metrics sample
    if version == 'v1.1':
        auc_score = random.randrange(810,925)/1000  # example score for the lab
    else:
        auc_score = random.randrange(670,790)/1000  # example score for the lab
    print(auc_score)
    
    # Evaluation file creation
    report_dict = {
        "binary_classification_metrics": {
            "auc" : {
                "value" : auc_score,
                "standard_deviation" : "0"
            },
        }
    }
    print(report_dict)
    
    # Upload evaluation file to S3
    s3object = s3.Object(data_bucket, 'evaluation.json')
    print(s3object)

    s3object.put(
        Body=(bytes(json.dumps(report_dict).encode('UTF-8')))
    )

    # Specify the model source
    modelpackage_inference_specification =  {
        "InferenceSpecification": {
            "Containers": [
                {
                    "Image": ecr_arn,
                    "ModelDataUrl": model_url
                }
            ],
            "SupportedContentTypes": [ "text/csv" ],
            "SupportedResponseMIMETypes": [ "text/csv" ],
        },
        "ModelMetrics": {
            'ModelQuality': {
                'Statistics': {
                    'ContentType': 'application/json',
                    'S3Uri': 's3://'+data_bucket+'/evaluation.json'
                }
            },
        }
    }
    
    create_model_package_input_dict = {
        "ModelPackageGroupName" : model_package_group_name,
        "ModelPackageDescription" : "Model to detect Abalone gender",
        "ModelApprovalStatus" : "PendingManualApproval"
    }
    create_model_package_input_dict.update(modelpackage_inference_specification)
    
    # Create the model package
    create_model_package_response = sagemaker.create_model_package(**create_model_package_input_dict)
    model_package_arn = create_model_package_response["ModelPackageArn"]
    print('ModelPackage Version ARN: {}'.format(model_package_arn))
