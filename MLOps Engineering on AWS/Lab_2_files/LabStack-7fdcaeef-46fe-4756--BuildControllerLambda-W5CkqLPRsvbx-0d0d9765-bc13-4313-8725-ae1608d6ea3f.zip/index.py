import boto3, botocore, sys, os, json
import random, string, re, logging, time
import uuid, shutil
import urllib.request
import botocore.waiter
import cfnresponse
from enum import Enum

codebuild = boto3.client('codebuild')
logger = logging.getLogger(__name__)

class WaitState(Enum):
  SUCCESS = 'success'
  FAILURE = 'failure'

class CustomWaiter:
  """
  Base class for a custom waiter that leverages botocore's waiter code. Waiters
  poll an operation, with a specified delay between each polling attempt, until
  either an accepted result is returned or the number of maximum attempts is reached.

  To use, implement a subclass that passes the specific operation, arguments,
  and acceptors to the superclass.

  For example, to implement a custom waiter for the transcription client that
  waits for both success and failure outcomes of the get_transcription_job function,
  create a class like the following:

  class TranscribeCompleteWaiter(CustomWaiter):
      def __init__(self, client):
          super().__init__(
              'TranscribeComplete', 'GetTranscriptionJob',
              'TranscriptionJob.TranscriptionJobStatus',
              {'COMPLETED': WaitState.SUCCESS, 'FAILED': WaitState.FAILURE},
              client)

      def wait(self, job_name):
          self._wait(TranscriptionJobName=job_name)
  """
  def __init__(
          self, name, operation, argument, acceptors, client, delay=10, max_tries=60,
          matcher='path'):
      """
      Subclasses should pass specific operations, arguments, and acceptors to
      their superclass.

      :param name: The name of the waiter. This can be any descriptive string.
      :param operation: The operation to wait for. This must match the casing of
                        the underlying operation model, which is typically in
                        CamelCase.
      :param argument: The dict keys used to access the result of the operation, in
                      dot notation. For example, 'Job.Status' will access
                      result['Job']['Status'].
      :param acceptors: The list of acceptors that indicate the wait is over. These
                        can indicate either success or failure. The acceptor values
                        are compared to the result of the operation after the
                        argument keys are applied.
      :param client: The Boto3 client.
      :param delay: The number of seconds to wait between each call to the operation.
      :param max_tries: The maximum number of tries before exiting.
      :param matcher: The kind of matcher to use.
      """
      self.name = name
      self.operation = operation
      self.argument = argument
      self.client = client
      self.waiter_model = botocore.waiter.WaiterModel({
          'version': 2,
          'waiters': {
              name: {
                  "delay": delay,
                  "operation": operation,
                  "maxAttempts": max_tries,
                  "acceptors": [{
                      "state": state.value,
                      "matcher": matcher,
                      "argument": argument,
                      "expected": expected
                  } for expected, state in acceptors.items()]
              }}})
      self.waiter = botocore.waiter.create_waiter_with_client(
          self.name, self.waiter_model, self.client)

  def __call__(self, parsed, **kwargs):
      """
      Handles the after-call event by logging information about the operation and its
      result.

      :param parsed: The parsed response from polling the operation.
      :param kwargs: Not used, but expected by the caller.
      """
      status = parsed
      for key in self.argument.split('.'):
          if key.endswith('[]'):
              status = status.get(key[:-2])[0]
          else:
              status = status.get(key)
      logger.info(
          "Waiter %s called %s, got %s.", self.name, self.operation, status)

  def _wait(self, **kwargs):
      """
      Registers for the after-call event and starts the botocore wait loop.

      :param kwargs: Keyword arguments that are passed to the operation being polled.
      """
      event_name = f'after-call.{self.client.meta.service_model.service_name}'
      self.client.meta.events.register(event_name, self)
      self.waiter.wait(**kwargs)
      self.client.meta.events.unregister(event_name, self)

class CodeBuildCompleteWaiter(CustomWaiter):
  def __init__(self, client):
      super().__init__(
          'BuildComplete', 'BatchGetBuilds',
          'build.0.buildStatus',
          {
              'SUCCEEDED': WaitState.SUCCESS,
              'FAILED': WaitState.FAILURE
          },
          client
      )

  def wait(self, build_id):
      self._wait(BuildId=build_id)

def handler(event, context):
  print(event)
  buildComplete = False

  build_project_name = event['ResourceProperties'].get('BuildStepFunctionProjectName')
  build_list = codebuild.list_builds_for_project(
      projectName=build_project_name
  )
  build_id = build_list['ids'][0]
  print("-" * 20)
  print("DEBUG:")
  print(f"build_project_name: {build_project_name}")
  print(f"build_list: {build_list}")
  print(f"build_id: {build_id}")
  print("-" * 20)

  responseData = {
      'status': 'NONE',
      'build_project_name': 'NONE',
      'build_id': 'NONE'
  }
  responseData['build_id'] = build_id
  responseData['build_project_name'] = build_project_name

  try:
    counter = 0
    while counter < 60:
        time.sleep(5)
        counter += 1
        build_in_progress = codebuild.batch_get_builds(ids=[build_id])
        print(f"DEBUG:\nbuild_in_progress:\n{build_in_progress}")
        buildStatus = build_in_progress['builds'][0]['buildStatus']
        responseData["status"] = buildStatus
        if buildStatus == 'SUCCEEDED':
            cfnresponse.send(event, context, "SUCCESS", responseData, event["LogicalResourceId"])
            break
        elif buildStatus == 'FAILED' or buildStatus == 'FAULT' or buildStatus == 'STOPPED' or buildStatus == 'TIMED_OUT':
            cfnresponse.send(event, context, "FAILED", responseData, event["LogicalResourceId"])
            break
  except Exception as e:
    responseData["status"] = e
    cfnresponse.send(event, context, "FAILED", responseData, event["LogicalResourceId"])
  
  # # this will run in case of timeout of the above while loop, and will also
  # # be removed once custom waiter is guaranteed to work
  # cfnresponse.send(event, context, "FAILED", responseData, event["LogicalResourceId"])

  # \/-- this will be the happy path after the gross bandaid above is in place
  # try:
  #     build_waiter = CodeBuildCompleteWaiter(codebuild)
  #     build_waiter.wait(build_id)
  #     responseData['status'] = 'COMPLETE'
  #     cfnresponse.send(event, context, "SUCCESS", responseData, event["LogicalResourceId"])
  # except:
  #     responseData['status'] = 'FAILURE'
  #     cfnresponse.send(event, context, "FAILED", responseData, event["LogicalResourceId"])
