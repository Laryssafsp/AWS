import logging
from random import randint
import cfnresponse

logging.basicConfig(level=logging.INFO)

def random_with_N_digits(len: int) -> str:
    """
    generate a random number of length 'len'
    """
    range_start = 10**(len-1)
    range_end = (10**len)-1
    randomnumber = str(randint(range_start, range_end))
    return randomnumber

def handler(event, context):
    # check if generated bucket name is already in use
    random_num = random_with_N_digits(int(event['ResourceProperties']['Length']))
    # return bucket name
    responseData = {"Random_Number": random_num}
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData, "Random_Number")
